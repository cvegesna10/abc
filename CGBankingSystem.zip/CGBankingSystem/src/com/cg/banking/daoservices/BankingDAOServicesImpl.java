package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static HashMap<Integer, Customer> customerList=new HashMap<>();
	private static int CUSTOMER_ID_COUNTER=1000;
	private static long ACCOUNT_ID_COUNTER=155112;
	private static int TRANSACTION_ID_COUNTER=254789;
	Random rand=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		 customerList.put(CUSTOMER_ID_COUNTER, customer);
		 customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		 return customer.getCustomerId();
		
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(ACCOUNT_ID_COUNTER, account);
		account.setAccountNo(ACCOUNT_ID_COUNTER++);
		account.setStatus("Active");
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(account.getAccountNo(), account);
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) { 
			long accountNo=account.getAccountNo();
			getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9999) + 1000);
			return getAccount(customerId, accountNo).getPinNumber(); 
	 

	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		getAccount(customerId, accountNo).getTransactionList().put(TRANSACTION_ID_COUNTER, transaction);
		transaction.setTransactionId(TRANSACTION_ID_COUNTER++);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		Customer c=customerList.remove(customerId);
		if(c==null)return false;
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		Account a=getCustomer(customerId).getAccountList().remove(accountNo);
		if(a==null)return false;
		return true;
		}

	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
		}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return getCustomer(customerId).getAccountList().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		 List<Customer> list =new ArrayList<>(customerList.values());
		 return list;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		 List<Account> list =new ArrayList<>(getCustomer(customerId).getAccountList().values());
		 return list;
		
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		List<Transaction> list =new ArrayList<>(getAccount(customerId, accountNo).getTransactionList().values());
		 return list;
	}
}
