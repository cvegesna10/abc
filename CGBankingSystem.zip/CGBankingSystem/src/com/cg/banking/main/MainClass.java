package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.beans.Customer;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl services=new BankingServicesImpl();
		
		try{
			/*Scanner i=new Scanner(System.in);
			int k=0;
			while (k!=11) {
				System.out.println("Select the Input\n"+"1)Register Customer\n2)Add Account\n3)Generate Pin\n4)Change Pin\n"
						+"5)Deposit Amount\n6)Withdraw Amount\n7)Fund Transfer\n8)Close Account\n"
						+"9)Remove Customer\n10)Get customer Details\n11)Exit Portal");
				k=i.nextInt();
			switch (k) {
			case 1:System.out.println("Enter Customer Details :");
			System.out.println("Enter First name");
			String firstName=i.next();
			System.out.println("Enter Last name");
			String lastName=i.next();
			System.out.println("Enter EmailId");
			String customerEmailId=i.next();
			System.out.println("Enter PAN card number");
			String panCard=i.next();
			System.out.println("Enter Local Address City");
			String localAddressCity=i.next();
			System.out.println("Enter Local Address state");
			String localAddressState=i.next();
			System.out.println("Enter Local Address pincode");
			int localAddressPinCode=i.nextInt();
			System.out.println("Enter Home Address City");
			String homeAddressCity=i.next();
			System.out.println("Enter Home Address State");
			String homeAddressState=i.next();
			System.out.println("Enter Home Address PinCode");
			int homeAddressPinCode=i.nextInt();
			int cusid=services.acceptCustomerDetails(firstName, lastName, customerEmailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
			System.out.println("Succesfully created customer with Id \n"+cusid);
			System.out.println((services.getCustomerDetails(cusid)).toString());
			break;
			case 2:System.out.println("Enter Account details");
			System.out.println("Enter the customer Id");
			int customerId=i.nextInt();
			System.out.println("Enter Account Type");
			String accountType=i.next();
			System.out.println("Enter Initial Balance");
			float initBalance=i.nextFloat();
			long acno=services.openAccount(customerId, accountType, initBalance);
			System.out.println("successfully added account "+acno+" for customer of id "+customerId+"\n");
			break;
			case 3:System.out.println("Enter the details to generate a PIN");
			System.out.println("Enter CustomerId");
			int customerId1=i.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo=i.nextLong();
			int pin=services.generateNewPin(customerId1,accountNo);
			System.out.println("The generated Pin is"+pin);
			break;
			case 4:System.out.println("Enter the details for pin change\n"+"customerId, AccountNo,OldPin,NewPin");
			boolean flag=services.changeAccountPin(i.nextInt(), i.nextLong(), i.nextInt(), i.nextInt());
			if(flag==true)
				System.out.println("Successfully pin changed");
			else
				System.out.println("Pin change failed give vaild details");
			break;
			

			default:
				break;
			}*/
		int cusId=services.acceptCustomerDetails("chandrahas", "vegesna", "varma@gmail.com", "BFSHT259", "pune", "Maharastra", 400020, "hyderabad", "Telangana", 500085);
		System.out.println(cusId);
		int cusId1=services.acceptCustomerDetails("vishal", "sai", "vishal@gmail.com", "HTWXD785", "pune", "Maharastra", 400020, "hyderabad", "Telangana", 500085);
		System.out.println(cusId1);
		long acno1=services.openAccount(1000, "savings", 1550);
		System.out.println(acno1);
		float bal=services.depositAmount(1000, 155112, 2500);
		System.out.println(bal);
		long acno2=services.openAccount(1000, "salary", 15250);
		System.out.println(acno2);
		float bal2=services.depositAmount(1000, 155113, 1000);
		System.out.println(bal2);
		int pin=services.getAccountDetails(1000, 155113).getPinNumber();
		System.out.println(services.getAccountDetails(1000, 155113).getPinCounter());
		System.out.println(services.withdrawAmount(1000, 155113,2000,pin));
		
		/*long acno21=services.openAccount(1001, "savings", 20500);
		System.out.println(acno21);
		float bal21=services.depositAmount(1001, 155114, 1500);
		System.out.println(bal21);
		int pin21=services.getAccountDetails(1001, 155114).getPinNumber();
		System.out.println(services.withdrawAmount(1001, 155114,2000, pin21));
		
		boolean b=services.fundTransfer(1001, 155114, 1000, 155113, 1, pin);
		
		
		Customer a1=services.getCustomerDetails(1000);
		System.out.println(a1.toString());
		Customer a2=services.getCustomerDetails(1001);
		System.out.println(a2.toString());*/
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}	
}
