package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;

public class PayrollDAOServicesImpl implements PayrollDAOServices {

	private static Associate[] associateList = new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;

	public PayrollDAOServicesImpl(){}

	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAOServices#insertAssociate(com.cg.payroll.beans.Associate)
	 */
	@Override
	public int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++] = associate;
		return associate.getAssociateID();
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAOServices#updateAssociate(com.cg.payroll.beans.Associate)
	 */
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null&&associate.getAssociateID()==associateList[i].getAssociateID()){
				associateList[i]=associate;
				return true;
			}
		}
		return false;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAOServices#deleteAssociate(int)
	 */
	@Override
	public boolean deleteAssociate(int associateId){
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null&&associateId==associateList[i].getAssociateID()){
				associateList[i]=null;
				return true;
			}
		}
		return false;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAOServices#getAssociate(int)
	 */
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++){
			if(associateId==associateList[i].getAssociateID()){
				return associateList[i];

			}
		}
		return null;
	}
	Associate[] getAssociates(){
		return associateList;
	}
}
