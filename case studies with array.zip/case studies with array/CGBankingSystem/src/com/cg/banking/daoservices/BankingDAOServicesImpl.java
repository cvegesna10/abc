package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import java.util.Random;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static Customer[] customerList=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=1000;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static long ACCOUNT_ID_COUNTER=155112;
	private static int TRANSACTION_ID_COUNTER=254789;
	Random rand=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		if(CUSTOMER_IDX_COUNTER>0.7*(customerList.length)){
			Customer[] tempArray=new Customer[customerList.length+10];
			System.arraycopy(customerList,0,tempArray,0,customerList.length);
			customerList=tempArray;
			}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++] = customer;
		return customer.getCustomerId();
		
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		if(getCustomer(customerId).getAccountIdxCounter()>0.7*(getAccounts(customerId).length)){
			Account[] tempArray1=new Account[getAccounts(customerId).length+5];
			System.arraycopy(getAccounts(customerId),0,tempArray1,0,getAccounts(customerId).length);
			getCustomer(customerId).setAccounts(tempArray1);
		}
		account.setAccountNo(ACCOUNT_ID_COUNTER++);
		getAccounts(customerId)[getCustomer(customerId).getAccountIdxCounter()]=account;
		getCustomer(customerId).setAccountIdxCounter(getCustomer(customerId).getAccountIdxCounter()+1);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for (int j = 0; j < getCustomer(customerId).getAccounts().length; j++) 
		if(getCustomer(customerId).getAccounts()[j].getAccountNo()==account.getAccountNo()){
			getCustomer(customerId).getAccounts()[j]=account;
			return true ;
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) { 
			long accountNo=account.getAccountNo();
			getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9999) + 1000);
			return getAccount(customerId, accountNo).getPinNumber(); 
	 

	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo).getTransactionIdxCounter()>0.7*getTransactions(customerId, accountNo).length){
			Transaction [] temp=new Transaction[getTransactions(customerId, accountNo).length+10];
			System.arraycopy(getTransactions(customerId, accountNo),0,temp,0,getTransactions(customerId, accountNo).length);
			getAccount(customerId, accountNo).setTransactions(temp);
		}
		transaction.setTransactionId(TRANSACTION_ID_COUNTER++);
		getTransactions(customerId, accountNo)[getAccount(customerId, accountNo).getTransactionIdxCounter()]=transaction;
		getAccount(customerId, accountNo).setTransactionIdxCounter(getAccount(customerId, accountNo).getTransactionIdxCounter()+1);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i].getCustomerId()==customerId){
				customerList[i]=null;
				adjustCustomerList();
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<getAccounts(customerId).length;i++){
			if(getAccounts(customerId)[i].getAccountNo()==accountNo){
				getAccounts(customerId)[i]=null;
				for(int j=i;j<getAccounts(customerId).length-1;j++){
					if(getAccounts(customerId)[j+1]!=null)
						getAccounts(customerId)[j]=getAccounts(customerId)[j+1];
					
				}
				getCustomer(customerId).setAccountIdxCounter(getCustomer(customerId).getAccountIdxCounter()-1);
			}
		}
		return false;
		
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerId==customerList[i].getCustomerId())
				return customerList[i];
			return null;
		
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for (int j = 0; j < getCustomer(customerId).getAccounts().length; j++) 
			if(getCustomer(customerId).getAccounts()[j].getAccountNo()==accountNo)
				return getCustomer(customerId).getAccounts()[j];
		return null;
	}

	@Override
	public Customer[] getCustomers() {
			return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		return getCustomer(customerId).getAccounts();
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return getAccount(customerId,accountNo).getTransactions();
	}
	
	public void adjustCustomerList(){
		for(int j=0;j<customerList.length;j++)
			if(customerList[j]==null)
				for (int k = j+1; k < customerList.length; k++)
					if(customerList[k]!=null){
						customerList[j]=customerList[k];
						customerList[k]=null;
						break;
					}
	}
	
}
