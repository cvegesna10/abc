package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		PayrollServices payrollServices=new PayrollServicesImpl();
		int empId=payrollServices.acceptAssociateDetails("chandrahas", "vegesna", "java", "varma@gmail.com", "analyst", "BCGD98564",150000 ,50000, 1000, 1000, 212, "CITI", "SCGFDS546");
		System.out.println(empId);
		System.out.println(payrollServices.calculateNetSalary(empId));
		Associate a1=payrollServices.getAssociateDetails(empId);
		System.out.println(a1.toString());
		
		int empId2=payrollServices.acceptAssociateDetails("vishal", "sai", "java", "vishal@gmail.com", "analyst", "ASGD98564",139000 ,25000, 1500, 1500, 212, "AXIS", "AXISDS546");
		System.out.println(empId2);
		System.out.println(payrollServices.calculateNetSalary(empId2));
		Associate a2=payrollServices.getAssociateDetails(empId2);
		System.out.println(a2.toString());
		
		payrollServices.updateAssociateDetails(112, "vishal", "jakkampudi", "java", "vishal@gmail.com", "analyst", "ASGD98564",86000 ,29000, 1500, 1500, 212, "AXIS", "AXISDS546");
		Associate a3=payrollServices.getAssociateDetails(112);
		System.out.println(payrollServices.calculateNetSalary(112));
		System.out.println(a3.toString());
		
		payrollServices.deleteAssociate(111);
		Associate[] a4=payrollServices.getAssociatesDetails();
		System.out.println(a4[0].toString());
	}
}
