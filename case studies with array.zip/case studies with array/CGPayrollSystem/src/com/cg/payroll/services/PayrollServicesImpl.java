package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
public class PayrollServicesImpl implements PayrollServices {
	private float annualTax;
	private PayrollDAOServices daoservices;
	public PayrollServicesImpl(){
		daoservices = new PayrollDAOServicesImpl();
	}
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, int, int, int, int, java.lang.String, java.lang.String)
	 */
	@Override
	public int acceptAssociateDetails(String firstName,String lastName,String department,String emailId,String designation,String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode){
		
		return daoservices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	 @Override
	public boolean updateAssociateDetails(int associateId,String firstName, String lastName, String department, String emailId,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode)throws AssociateDetailsNotfoundException {
		boolean a= daoservices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));	
		if(a==false)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
	return a;
	 }
	 @Override
	 public boolean deleteAssociate(int associateId)throws AssociateDetailsNotfoundException{
		 boolean a= daoservices.deleteAssociate(associateId);
		 if(a==false)
				throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		return a; 
	 }
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException{
		Associate associate = this.getAssociateDetails(associateId);
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.5f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf());
			float annualsalary=12*associate.getSalary().getGrossSalary();
			if((associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf())<150000)) {
				if(annualsalary>=1000000) 
					annualTax=(annualsalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
				else if(annualsalary>=500000&&annualsalary<1000000) 
					annualTax=(0.2f*(annualsalary-500000)+(0.1f*(150000-(associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf()))));
				else if(annualsalary<500000 && annualsalary>=250000){
					if(annualsalary-250000>(associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()))
						annualTax=0.1f*(annualsalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf()));
					else 
						annualTax=0;
				}
				else if(annualsalary<250000)
					annualTax=0;
			}
			else {
				if(annualsalary>=1000000) 
					annualTax=((annualsalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
				else if(annualsalary>=500000&&annualsalary<1000000)
					annualTax=(0.2f*(annualsalary-500000)+(0.1f*100000));
				else if(annualsalary<500000 && annualsalary>=250000)
					if(annualsalary-250000>(associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()))
						annualTax=0.1f*(annualsalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf()));
					else 
						annualTax=0;
				else
					annualTax=0;
			}
			associate.getSalary().setMonthlyTax(annualTax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
	return associate.getSalary().getNetSalary();
		}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotfoundException {
		Associate associate = daoservices.getAssociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		return associate;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails()
	 */
	public Associate[] getAssociatesDetails(){
		return daoservices.getAssociates();
	}
		
	
}
