package com.cg.airreservation.beans;

public class Journey {
	String fromCity,toCity;
	
}
