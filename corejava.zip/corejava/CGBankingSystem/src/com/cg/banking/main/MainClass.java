package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl services=new BankingServicesImpl();
		int k=0;
		File file=new File("d:\\bankdata.txt");
			try {
				
				if(file.exists()==false)
				file.createNewFile();
				services.deSerialization(file);
			} catch (IOException e1) {
				e1.printStackTrace();
				e1.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				e.printStackTrace();
			}
	
		while (k!=16) {
		try{
			Scanner i=new Scanner(System.in);
			System.out.println("Select the Input\n"+"1)Register Customer\n2)Add Account\n3)Generate Pin\n4)Change Pin\n"
						+"5)Deposit Amount\n6)Withdraw Amount\n7)Fund Transfer\n8)Customer Details\n9)Account Details\n10)Close Account\n"
						+"11)Remove Customer\n12)Get all customer Details\n13)Get all account Details\n14)Get all Transaction Details\n15)Get Account status\n16)Exit Portal");
				k=i.nextInt();
				
			switch (k) {
			case 1:System.out.println("Enter Customer Details :");
			System.out.println("Enter First name");
			String firstName=i.next();
			System.out.println("Enter Last name");
			String lastName=i.next();
			System.out.println("Enter EmailId");
			String customerEmailId=i.next();
			System.out.println("Enter PAN card number");
			String panCard=i.next();
			System.out.println("Enter Local Address City");
			String localAddressCity=i.next();
			System.out.println("Enter Local Address state");
			String localAddressState=i.next();
			System.out.println("Enter Local Address pincode");
			int localAddressPinCode=i.nextInt();
			System.out.println("Enter Home Address City");
			String homeAddressCity=i.next();
			System.out.println("Enter Home Address State");
			String homeAddressState=i.next();
			System.out.println("Enter Home Address PinCode");
			int homeAddressPinCode=i.nextInt();
			int cusid=services.acceptCustomerDetails(firstName, lastName, customerEmailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
			System.out.println("Succesfully created customer with Id \n"+cusid);
			System.out.println((services.getCustomerDetails(cusid)).toString());
			break;
			case 2:System.out.println("Enter Account details");
			System.out.println("Enter the customer Id");
			int customerId=i.nextInt();
			System.out.println("Enter Account Type");
			String accountType=i.next();
			System.out.println("Enter Initial Balance");
			float initBalance=i.nextFloat();
			long acno=services.openAccount(customerId, accountType, initBalance);
			System.out.println("successfully added account "+acno+" for customer of id "+customerId+"\n");
			break;
			case 3:System.out.println("Enter the details to generate a PIN");
			System.out.println("Enter CustomerId");
			int customerId1=i.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo=i.nextLong();
			int pin=services.generateNewPin(customerId1,accountNo);
			System.out.println("The generated Pin is"+pin);
			break;
			case 4:System.out.println("Enter the details for pin change\n"+"customerId, AccountNo,OldPin,NewPin");
			boolean flag=services.changeAccountPin(i.nextInt(), i.nextLong(), i.nextInt(), i.nextInt());
			if(flag==true) System.out.println("Successfully pin changed");
			else System.out.println("Pin change failed ,Give vaild details");
			break;
			case 5:System.out.println("Enter the details to deposit :");
			System.out.println("Enter customerId");
			int customerId2=i.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo1=i.nextLong();
			System.out.println("Enter the amount");
			int amount=i.nextInt();
			float balance=services.depositAmount(customerId2, accountNo1, amount);
			System.out.println("Balance Amount : "+balance);
			break;
			case 6:System.out.println("Enter the details to withdraw :");
			System.out.println("Enter customerId");
			int customerId3=i.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo2=i.nextLong();
			System.out.println("Enter the amount");
			int amount1=i.nextInt();
			System.out.println("Enter the pin number");
			int pin1=i.nextInt();
			float bal=services.withdrawAmount(customerId3, accountNo2, amount1, pin1);
			System.out.println("Balance Amount : "+bal);
			break;
			case 7:System.out.println("Enter the details for fund transfer :");
			System.out.println("Enter customerId of receiver ");
			int cusIdTo=i.nextInt();
			System.out.println("Enter customerId of sender ");
			int cusIdFrom=i.nextInt();
			System.out.println("Enter account number of receiver ");
			long accountNumberTo=i.nextLong();
			System.out.println("Enter account number of sender ");
			long accountNumberFrom=i.nextLong();
			System.out.println("Enter the amount to be transfered");
			int amount2=i.nextInt();
			System.out.println("Enter the pin number");
			int pin2=i.nextInt();
			boolean b=services.fundTransfer(cusIdTo, accountNumberTo, cusIdFrom, accountNumberFrom, amount2, pin2);
			if(b==true) System.out.println("Fund Transfer successfull");
			else System.out.println("Fund Transfer failed");
			break;
			case 8: System.out.println("Enter customerId to get customer details");
			int customerId4=i.nextInt();
			System.out.println(services.getCustomerDetails(customerId4));
			break;
			case 9: System.out.println("Enter customerId to get account details");
			int customerId5=i.nextInt();
			System.out.println("Enter account number to get account details");
			long accountNo3=i.nextLong();
			System.out.println(services.getAccountDetails(customerId5, accountNo3));
			break;
			case 10:System.out.println("Enter customerId and account number to close the account");
			boolean c=services.closeAccount(i.nextInt(), i.nextLong());
			if(c==true) System.out.println("Account is closed");
			else System.out.println("Account close failed");
			break;
			case 11:System.out.println("Enter customerId to remove customer");
			int customerId6=i.nextInt();
			boolean d=services.removeCustomer(customerId6);
			if(d==true) System.out.println("Customer is removed");
			else System.out.println("customer removal failed");
			break;
			case 12:System.out.println("Get all customer details");
			System.out.println(services.getAllCustomerDetails());
			break;
			case 13:System.out.println("Enter the customerId to get all account details");
			int customerId7=i.nextInt();
			System.out.println(services.getcustomerAllAccountDetails(customerId7));
			break;
			case 14:System.out.println("Enter the customerId and account number to get all transaction details");
			System.out.println(services.getAccountAllTransaction(i.nextInt(), i.nextLong()));
			break;
			case 15:System.out.println("Enter the customerId and account number to get account status");
			System.out.println(services.accountStatus(i.nextInt(), i.nextLong()));
			break;
			default:
				services.serialization(file);
				break;
			}
		}	
		
		catch(AccountBlockedException e){
			e.printStackTrace();
		}
		catch(AccountNotFoundException e){
			e.printStackTrace();
		}
		catch (BankingServicesDownException e) {
			e.printStackTrace();
		}
		catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}
		catch (InsufficientAmountException e) {
			e.printStackTrace();
		}
		catch (InvalidAccountTypeException e) {
			e.printStackTrace();
		}
		catch (InvalidAmountException e) {
			e.printStackTrace();
		}
		catch (InvalidPinNumberException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}	
}
/*int cusId=services.acceptCustomerDetails("chandrahas", "vegesna", "varma@gmail.com", "BFSHT259", "pune", "Maharastra", 400020, "hyderabad", "Telangana", 500085);
System.out.println(cusId);
int cusId1=services.acceptCustomerDetails("vishal", "sai", "vishal@gmail.com", "HTWXD785", "pune", "Maharastra", 400020, "hyderabad", "Telangana", 500085);
System.out.println(cusId1);
long acno1=services.openAccount(1000, "savings", 1550);
System.out.println(acno1);
float bal=services.depositAmount(1000, 155112, 2500);
System.out.println(bal);
long acno2=services.openAccount(1000, "salary", 15250);
System.out.println(acno2);
float bal2=services.depositAmount(1000, 155113, 1000);
System.out.println(bal2);
int pin=services.getAccountDetails(1000, 155113).getPinNumber();
System.out.println(services.getAccountDetails(1000, 155113).getPinCounter());
System.out.println(services.withdrawAmount(1000, 155113,2000,pin));

/*long acno21=services.openAccount(1001, "savings", 20500);
System.out.println(acno21);
float bal21=services.depositAmount(1001, 155114, 1500);
System.out.println(bal21);
int pin21=services.getAccountDetails(1001, 155114).getPinNumber();
System.out.println(services.withdrawAmount(1001, 155114,2000, pin21));

boolean b=services.fundTransfer(1001, 155114, 1000, 155113, 1, pin);


Customer a1=services.getCustomerDetails(1000);
System.out.println(a1.toString());
Customer a2=services.getCustomerDetails(1001);
System.out.println(a2.toString());*/
