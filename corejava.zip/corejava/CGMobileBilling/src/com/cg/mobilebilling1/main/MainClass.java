package com.cg.mobilebilling1.main;
import com.cg.mobilebilling1.*;
import com.cg.mobilebilling1.beans.Address;
import com.cg.mobilebilling1.beans.Bill;
import com.cg.mobilebilling1.beans.Customer;
import com.cg.mobilebilling1.beans.Plan;
import com.cg.mobilebilling1.beans.PostPaidAccount; 
public class MainClass {
	public static void main(String[] args) {
		Customer customer = new Customer();
		customer.setMobileNo(12345);
		System.out.println(customer.getMobileNo());
		Address address = new Address("Hyd", "Tg", "India", 500085);
		System.out.println(address.getCountry());
		Bill bill = new Bill();
		bill.setNoOfLocalCalls(56);
		System.out.println(bill.getNoOfLocalCalls());
		Plan plan = new Plan();
		plan.setPlanID(98653);
		System.out.println(plan.getPlanID());
	
	}
}
