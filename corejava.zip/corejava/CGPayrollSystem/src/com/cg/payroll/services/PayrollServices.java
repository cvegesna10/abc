package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.exception.PayrollServicesDown;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String department, String emailId, String designation,
			String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode) throws PayrollServicesDown;
	
	
	public boolean deleteAssociate(int associateId)throws AssociateDetailsNotfoundException,SQLException;
		
	float calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException,SQLException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotfoundException,SQLException;

	List<Associate> getAllAssociatesDetails();



	boolean updateAssociateDetails(int associateId, String firstName, String lastName, String department,
			String emailId, String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode)
			throws AssociateDetailsNotfoundException, PayrollServicesDown;

	

	}