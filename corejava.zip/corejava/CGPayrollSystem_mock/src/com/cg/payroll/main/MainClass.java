package com.cg.payroll.main;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		PayrollServices payrollServices=new PayrollServicesImpl();
		int i=0;
		while (i!=8) {
			System.out.println("Choose any option:\n1. For New Associate\n2. For Associate Details\n3. All Associate Details\n4. For Delete Associate\n5. For Update Associate\n6. For Claculation of net Salary\n7. Exit");
			Scanner scr=new Scanner(System.in);
			i= scr.nextInt();
			try{
				PayrollServices payrollServicesImpl =new PayrollServicesImpl();
				switch (i) {
				case 1:
					System.out.println("Enter first name:\t");
					String firstName= scr.next();
					System.out.println("Enter last name:\t");
					String lastName= scr.next();
					System.out.println("Enter emailId:\t");
					String emailId= scr.next();
					System.out.println("Enter Department:\t");
					String department= scr.next();
					System.out.println("Enter Designation:\t");
					String designation= scr.next();
					System.out.println("Enter pancard:\t");
					String pancard= scr.next();
					System.out.println("Enter yearlyInvestmentUnder80C:\t");
					int yearlyInvestmentUnder80C= scr.nextInt();
					System.out.println("Enter basic salary:\t");
					int basicSalary= scr.nextInt();
					System.out.println("Enter epf:\t");
					int epf= scr.nextInt();
					System.out.println("Enter companyPf:\t");
					int companyPf= scr.nextInt();
					System.out.println("Enter Account Number\t");
					int accountNumber=scr.nextInt();
					System.out.println("Enter Bank Name:\t");
					String bankName=scr.next();
					System.out.println("Enyer IFSC-CODE");
					String ifscCode=scr.next();
					System.out.println("Associate Id is"+" "+payrollServicesImpl.acceptAssociateDetails(firstName, lastName, department, emailId, designation, pancard, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode));
					break;
				case 2:
					System.out.println("Enyer AssociateID:\t");
					int associateID=scr.nextInt();
					System.out.println(payrollServicesImpl.getAssociateDetails(associateID));
					break;
				case 3:
					List<Associate> associate=payrollServicesImpl.getAllAssociatesDetails();
					for (Associate	a	: associate)
						System.out.println(a);
					break;
				case 4:
					System.out.println("Enyer AssociateID:\t");
					int associateID1=scr.nextInt();
					System.out.println(payrollServicesImpl.deleteAssociate(associateID1));
					break;
				case 5:
					System.out.println("Enyer AssociateID:\t");
					int associateID2=scr.nextInt();
					System.out.println("Enter first name:\t");
					String firstName1= scr.next();
					System.out.println("Enter last name:\t");
					String lastName1= scr.next();
					System.out.println("Enter emailId:\t");
					String emailId1= scr.next();
					System.out.println("Enter Department:\t");
					String department1= scr.next();
					System.out.println("Enter Designation:\t");
					String designation1= scr.next();
					System.out.println("Enter pancard:\t");
					String pancard1= scr.next();
					System.out.println("Enter yearlyInvestmentUnder80C:\t");
					int yearlyInvestmentUnder80C1= scr.nextInt();
					System.out.println("Enter basic salary:\t");
					int basicSalary1= scr.nextInt();
					System.out.println("Enter epf:\t");
					int epf1= scr.nextInt();
					System.out.println("Enter companyPf:\t");
					int companyPf1= scr.nextInt();
					System.out.println("Enter Account Number\t");
					int accountNumber1=scr.nextInt();
					System.out.println("Enter Bank Name:\t");
					String bankName1=scr.next();
					System.out.println("Enyer IFSC-CODE");
					String ifscCode1=scr.next();
					System.out.println(payrollServicesImpl.updateAssociateDetails(associateID2, firstName1, lastName1, emailId1, department1, designation1, pancard1, yearlyInvestmentUnder80C1, basicSalary1, epf1, companyPf1, accountNumber1, bankName1, ifscCode1));
					break;
				case 6:
					System.out.println("Enyer AssociateID:\t");
					int associateID3=scr.nextInt();
					System.out.println(payrollServicesImpl.calculateNetSalary(associateID3));
					break;
				case 7:
					break;
				}


			}
			catch(Exception e) {
				e.printStackTrace();


			}



		}
	}
		
		
		
		
		
		
		
		
		
		
		
		/*int empId=payrollServices.acceptAssociateDetails("chandrahas", "vegesna", "java", "varma@gmail.com", "analyst", "BCGD98564",150000 ,50000, 1000, 1000, 212, "CITI", "SCGFDS546");
		System.out.println(empId);
		System.out.println(payrollServices.calculateNetSalary(empId));
		Associate a1=payrollServices.getAssociateDetails(empId);
		System.out.println(a1.toString());
		
		int empId2=payrollServices.acceptAssociateDetails("vishal", "sai", "java", "vishal@gmail.com", "analyst", "ASGD98564",139000 ,25000, 1500, 1500, 212, "AXIS", "AXISDS546");
		System.out.println(empId2);
		System.out.println(payrollServices.calculateNetSalary(empId2));
		Associate a2=payrollServices.getAssociateDetails(empId2);
		System.out.println(a2.toString());
		
		payrollServices.updateAssociateDetails(112, "vishal", "jakkampudi", "java", "vishal@gmail.com", "analyst", "ASGD98564",86000 ,29000, 1500, 1500, 212, "AXIS", "AXISDS546");
		Associate a3=payrollServices.getAssociateDetails(112);
		System.out.println(payrollServices.calculateNetSalary(112));
		System.out.println(a3.toString());
		
		payrollServices.deleteAssociate(111);
		Associate[] a4=payrollServices.getAssociatesDetails();
		System.out.println(a4[0].toString());*/
	}

