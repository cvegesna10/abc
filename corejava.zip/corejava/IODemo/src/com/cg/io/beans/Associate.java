package com.cg.io.beans;

public class Associate {
	private String firstName,lastName;
	private int associateId;
	public Associate(){}
	public Associate(String firstName, String lastName, int associateId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.associateId = associateId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	
}
