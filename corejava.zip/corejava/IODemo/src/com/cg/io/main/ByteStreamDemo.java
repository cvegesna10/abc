package com.cg.io.main;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ByteStreamDemo {
	public static void byteReadWriteWork(File fromFile,File toFile) throws IOException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(toFile))) {
				
				/*int a=0;
				while((a=src.read())!=-1){
					System.out.print((char)a);
					//dest.write(a);
				}
				byte[] databuffer=new byte[(int) fromFile.length()];
				src.read(databuffer);
				System.out.print(new String(databuffer));
				dest.write(databuffer);*/
				
				
		}
	}
		
		
		
	}
}
