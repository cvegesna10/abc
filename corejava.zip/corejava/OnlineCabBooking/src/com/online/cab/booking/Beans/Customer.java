package com.online.cab.booking.Beans;

public class Customer {
	private String name,emailID,password;
	private long mobileNo;
	public Customer(){}
	public Customer(String name, String emailID, String password, long mobileNo) {
		super();
		this.name = name;
		this.emailID = emailID;
		this.password = password;
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
}
