package com.online.cab.booking.Beans;

public class DriverDetails {
	private int driverid,driverliscencenumber;
	private String drivername;
	public DriverDetails(){}
	public DriverDetails(int driverid, int driverliscencenumber, String drivername) {
		super();
		this.driverid = driverid;
		this.driverliscencenumber = driverliscencenumber;
		this.drivername = drivername;
	}
	public int getDriverid() {
		return driverid;
	}
	public void setDriverid(int driverid) {
		this.driverid = driverid;
	}
	public int getDriverliscencenumber() {
		return driverliscencenumber;
	}
	public void setDriverliscencenumber(int driverliscencenumber) {
		this.driverliscencenumber = driverliscencenumber;
	}
	public String getDrivername() {
		return drivername;
	}
	public void setDrivername(String drivername) {
		this.drivername = drivername;
	}
	
}