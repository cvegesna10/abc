package com.cg.project.main;

import com.cg.project.beans.CEmployee;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;

public class MainClass {

	public static void main(String[] args) {
	/*	Employee employee=new Employee(1000, 25000, "chandrahas", "vegesna");
		employee.calculateSalary();
		System.out.println(employee.toString());
		
		PEmployee pemployee=new PEmployee(1256, 25000, "daya", "samala");
		pemployee.calculateSalary();
		System.out.println(pemployee.toString());
		
		CEmployee cemployee=new CEmployee(5698, 19889, "ravi", "Teja");
		cemployee.setHrs(95);
		cemployee.calculateSalary();
		System.out.println(cemployee.toString());*/
		
		
		Employee employee=new CEmployee(1234, 26333, "chandrahas", "vegesna");
		employee.calculateSalary();
		System.out.println(employee.toString());
		
		CEmployee cemployee=new CEmployee();
		cemployee=(CEmployee)employee;
		cemployee.contractSign();
		System.out.println(cemployee.toString());
	}

}
