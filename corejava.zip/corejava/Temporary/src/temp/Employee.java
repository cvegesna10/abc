package temp;

public class Employee {

}
