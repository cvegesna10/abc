package temp;

public class MainClass {
	public static void main(String[] args){
		Square square1 = new Square();
		square1.setI(6);;
		System.out.println(square1.getArea());
		System.out.println(Square.squareno);
		Square square2 = new Square(4);
		System.out.println(square2.getArea());
		System.out.println(Square.squareno);
		System.out.println(square1.squareno);
		System.out.println(square2.squareno);
		Square square3 = new Square(4);
		System.out.println(square2.squareno);
	}
}
