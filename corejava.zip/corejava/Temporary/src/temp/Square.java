package temp;

public class Square {
	private int i,area;
	public static int squareno;
	public Square(){}
	public Square(int i) {
		int area;
		area=i*i;
		this.area=area;
	
		squareno++;
	}
	
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public static int getSquareno() {
		return squareno;
	}
	public static void setSquareno(int squareno) {
		Square.squareno = squareno;
	}
	
}
