package com.cg.airreservation.beans;

public class Flight {
	
}
