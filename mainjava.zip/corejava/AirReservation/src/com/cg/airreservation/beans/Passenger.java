package com.cg.airreservation.beans;

public class Passenger {
	private String firstname,lastname,gender;
	private long mobilenumber,adharnumber;
	private int age;
	private Journey journey;
	public Passenger(){}
	
}
