package com.cg.airreservation.beans;

public class TicketDetails {
		 private String ticketNo,boardingPoint,dropPoint,departureTime,arrivalTime,typeOfClass,departuredate,arrivaldate;
		 private Transaction transaction;
		
		public TicketDetails(){}
		
		
}
