package com.cg.airreservation.beans;

public class Transaction {
	private String type;
	private int amount,id; 
	public Transaction(){}
	
	
}
