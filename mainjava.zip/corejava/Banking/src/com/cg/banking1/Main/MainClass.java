package com.cg.banking1.Main;

public class MainClass {
	public static void main(String[] args) {

	}
}
