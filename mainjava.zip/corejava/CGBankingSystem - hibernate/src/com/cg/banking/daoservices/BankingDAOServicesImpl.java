package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.CGBankingUtility;
import com.cg.payroll.beans.Associate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
@Component(value="BankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices,Serializable {
	@Autowired
	private SessionFactory sessionFactory;	
	private Session session;
	org.hibernate.Transaction tx;

	@Override
	public int insertCustomer(Customer customer) {
		try{
			session=sessionFactory.openSession();
			tx=session.beginTransaction();
			int custId=(int) session.save(customer);
			tx.commit();
			return custId;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		try{
			session=sessionFactory.openSession();
			tx=session.beginTransaction();
			account.setCustomer(getCustomer(customerId));
			account.setStatus("Active");
			long accnum=(long) session.save(account);
			tx.commit();
			return accnum;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		session=sessionFactory.openSession();
	    tx=session.beginTransaction();
		session.update(account);
		tx.commit();
		session.flush();
		return true;
	}

	
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		try{
			session=sessionFactory.openSession();
			tx=session.beginTransaction();
			Account account=getAccount(customerId, accountNo);
			account.setCustomer(getCustomer(customerId));
			transaction.setAccount(account);
		    session.save(transaction);
			tx.commit();
			return true;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
		Customer customer=getCustomer(customerId);
		session.delete(customer);
		tx.commit();
		session.flush();
		return true;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		session=sessionFactory.openSession();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		return customer;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Account account=(Account) session.get(Account.class, accountNo);
		session.close();
		return account;
	}
	@Override
	public List<Customer> getCustomers() {
		return null;
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		return null;
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return null;
	}
	
	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}
}
