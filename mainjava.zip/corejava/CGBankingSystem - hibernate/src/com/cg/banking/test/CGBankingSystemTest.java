package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.CGBankingUtility;

public class CGBankingSystemTest {
	private static BankingServices bankingServices;
	
	@BeforeClass
	public static void setUpTestEnv(){
		bankingServices=new BankingServicesImpl();
	}	
	@Before
	public void setUpMockData(){
		Customer customer1=new Customer("chandrahas", "vegesna", "varma@gmail.com", "NSXGS25762", new Address(500085, "hyd", "telanagana"), new Address(500085, "hyd", "telangana"));
		customer1.setCustomerId(CGBankingUtility.CUSTOMER_ID_COUNTER);
		
		Account account1=new Account("savings", 26000);
		account1.setAccountNo(CGBankingUtility.ACCOUNT_ID_COUNTER++);
		account1.setStatus("Active");
		account1.setPinNumber(1111);
		
		Transaction transaction1=new Transaction(CGBankingUtility.TRANSACTION_ID_COUNTER, 1000, "deposit");
		transaction1.setTransactionId(CGBankingUtility.TRANSACTION_ID_COUNTER++);
		
		BankingDAOServicesImpl.customerList.put(CGBankingUtility.CUSTOMER_ID_COUNTER++, customer1);
		BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).getAccountList().put(account1.getAccountNo(), account1);
		BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).getAccountList().get(account1.getAccountNo()).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		
	
		Customer customer2=new Customer("daya", "samala", "daya@gmail.com", "OPQJS5552", new Address(500085, "hyd", "telanagana"), new Address(500085, "hyd", "telangana"));
		customer2.setCustomerId(CGBankingUtility.CUSTOMER_ID_COUNTER);
		
		Account account2=new Account("salary", 35000);
		account2.setAccountNo(CGBankingUtility.ACCOUNT_ID_COUNTER++);
		account2.setStatus("Active");
		account2.setPinNumber(2222);
		
		Transaction transaction2=new Transaction(CGBankingUtility.TRANSACTION_ID_COUNTER, 2000, "deposit");
		transaction2.setTransactionId(CGBankingUtility.TRANSACTION_ID_COUNTER++);
		
		BankingDAOServicesImpl.customerList.put(CGBankingUtility.CUSTOMER_ID_COUNTER++, customer2);
		BankingDAOServicesImpl.customerList.get(customer2.getCustomerId()).getAccountList().put(account2.getAccountNo(), account2);
		BankingDAOServicesImpl.customerList.get(customer2.getCustomerId()).getAccountList().get(account2.getAccountNo()).getTransactionList().put(transaction2.getTransactionId(), transaction2);
		
	}
	@Test
	public void testForAcceptCustomerForValidCustomerId() throws BankingServicesDownException{
		int expectedCustomerId=1002;
		assertEquals(expectedCustomerId,bankingServices.acceptCustomerDetails("meher", "prasad", "meher@gmail.com", "TYJHFC245", "hyd", "ts", 500085, "hyd", "ts", 500085));
	}
	@Test()
	public void testForAcceptCustomerForInValidCustomerId() throws BankingServicesDownException{
		int expectedCustomerId=1003;
		assertNotEquals(expectedCustomerId,bankingServices.acceptCustomerDetails("meher", "prasad", "meher@gmail.com", "TYJHFC245", "hyd", "ts", 500085, "hyd", "ts", 500085));
	}
	@Test
	public void testForOpenAccountForValidAccountNo() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		long expectedAccountNo=155114;
		assertEquals(expectedAccountNo, bankingServices.openAccount(1000, "savings", 10000));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForOpenAccountForinValidCustomerId() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(1, "salary", 1000);
	}
	@Test
	public void testForOpenAccountForValidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		bankingServices.openAccount(1000, "salary", 1000);
		String actualAccountType=bankingServices.getAccountDetails(1000, 155114).getAccountType();
		assertTrue(actualAccountType.equals("salary")||actualAccountType.equals("savings")||actualAccountType.equals("current"));
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testForOpenAccountForinValidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		bankingServices.openAccount(1000, "abc", 2500);
	}
	@Test
	public void testForOpenAccountForValidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		bankingServices.openAccount(1000, "salary", 1000);
		float actualAmount=bankingServices.getAccountDetails(1000, 155114).getAccountBalance();
		assertTrue(actualAmount>0);
	}
	@Test(expected=InvalidAmountException.class)
	public void testForOpenAccountForInValidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		bankingServices.openAccount(1000, "salary", -10);
	}
	@Test
	public void testForDepositAmountForValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float expectedBalance=36000;
		assertEquals(expectedBalance, bankingServices.depositAmount(1000, 155112, 10000),2);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForDepositAmountForInValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(25, 155112, 10000);
	}
	@Test
	public void testForDepositAmountForValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float expectedBalance=31000;
		assertEquals(expectedBalance, bankingServices.depositAmount(1000, 155112, 5000),2);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testForDepositAmountForInValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(1000, 00001, 10000);
	}
	@Test
	public void testForDepositAmountForActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(1000, 155112, 10000);
		String expectedAccountType="Active";
		assertEquals(expectedAccountType, bankingServices.getAccountDetails(1000, 155112).getStatus());
	}
	@Test(expected=AccountBlockedException.class)
	public void testForDepositAmountForInActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.getAccountDetails(1000, 155112).setStatus("Blocked");
		bankingServices.depositAmount(1000, 155112, 10);
	}
	@Test
	public void testForDepositAmountForValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		assertEquals(36000,bankingServices.depositAmount(1000, 155112, 10000),2);
	}
	@Test(expected=InvalidAmountException.class)
	public void testForDepositAmountForInValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(1000, 155112, -10);
	}
	
	
	
	
	@Test
	public void testForWithdrawAmountForValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		float expectedBalance=16000;
		assertEquals(expectedBalance, bankingServices.withdrawAmount(1000, 155112, 10000, 1111),2);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForWithdrawAmountForInValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1, 155112, 1, 1111);
	}
	@Test
	public void testForWithdrawAmountForValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		float expectedBalance=21000;
		assertEquals(expectedBalance, bankingServices.withdrawAmount(1000, 155112, 5000, 1111),2);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testForWithdrawAmountForInValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000, 001, 100, 1111);
	}
	@Test
	public void testForWithdrawAmountForActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000, 155112, 1, 1111);
		String expectedAccountType="Active";
		assertEquals(expectedAccountType, bankingServices.getAccountDetails(1000, 155112).getStatus());
	}
	@Test(expected=AccountBlockedException.class)
	public void testForWithdrawAmountForInActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.getAccountDetails(1000, 155112).setStatus("Blocked");
		bankingServices.withdrawAmount(1000, 155112, 10, 1111);
	}
	@Test
	public void testForWithdrawAmountForValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		assertEquals(16000,bankingServices.withdrawAmount(1000, 155112, 10000, 1111),2);
	}
	@Test(expected=InvalidAmountException.class)
	public void testForWithdrawAmountForInValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000, 155112, -110, 1111);
	}
	@Test
	public void testForWithdrawAmountForSufficientAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000, 155112, 10, 1111);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testForWithdrawAmountForInSufficientAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000,155112,50000,1111);
	}
	@Test
	public void testForWithdrawAmountForValidPin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000, 155112, 10, 1111);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testForWithdrawAmountForInValidPin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(1000,155112,100,007);
	}
	
	
	
	
	
	@Test
	public void testForFundTransferForValidSenderCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		boolean expected=true;
		assertEquals(expected, bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForFundTransferForInValidSenderCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 9999, 155112, 10, 1111);
	}
	@Test
	public void testForFundTransferForValidReceiverCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		boolean expected=true;
		assertEquals(expected, bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForFundTransferForInValidReceiverCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(9999, 155113, 1000, 155112, 10, 1111);
	}
	@Test
	public void testForFundTransferForValidSenderAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		boolean expected=true;
		assertEquals(expected, bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testForFundTransferForInValidSenderAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 007, 10, 1111);
	}
	@Test
	public void testForFundTransferForValidReceiverAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		boolean expected=true;
		assertEquals(expected, bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testForFundTransferForInValidReceiverAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 0007, 1000, 155112, 10, 1111);
	}
	@Test
	public void testForFundTransferForSenderActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
		String expectedAccountType="Active";
		assertEquals(expectedAccountType, bankingServices.getAccountDetails(1000, 155112).getStatus());
	}
	@Test(expected=AccountBlockedException.class)
	public void testForFundTransferForSenderInActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.getAccountDetails(1000, 155112).setStatus("Blocked");
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
	}
	@Test
	public void testForFundTransferForReceiverActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
		String expectedAccountType="Active";
		assertEquals(expectedAccountType, bankingServices.getAccountDetails(1001, 155113).getStatus());
	}
	@Test(expected=AccountBlockedException.class)
	public void testForFundTransferForReceiverInActiveAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.getAccountDetails(1001, 155113).setStatus("Blocked");
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
	}
	@Test
	public void testForFundTransferForValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		assertTrue(bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111));
	}
	@Test(expected=InvalidAmountException.class)
	public void testForFundTransferForInValidAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, -20, 1111);
	}
	@Test
	public void testForFundTransferForSufficientAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testForFundTransferForInSufficientAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 90000, 1111);
	}
	@Test
	public void testForFundTransferForValidPin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 1111);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testForFundTransferForInValidPin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.fundTransfer(1001, 155113, 1000, 155112, 10, 123);
	}
	@Test
	public void testForGetCustomerDetailsForValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		float expectedBalance=16000;
		assertEquals(expectedBalance, bankingServices.withdrawAmount(1000, 155112, 10000, 1111),2);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForGetCustomerDetailsForInValidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.withdrawAmount(5, 155112, 1, 1111);
	}
	@Test
	public void testForGetAccountDetailsForValidCustomerId() throws CustomerNotFoundException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float expectedBalance=16000;
		assertEquals(expectedBalance, bankingServices.withdrawAmount(1000, 155112, 10000, 1111),2);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForGetAccountDetailsForInValidCustomerId() throws CustomerNotFoundException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.withdrawAmount(500, 155112, 1, 1111);
	}
	@Test
	public void testForGetAccountDetailsForValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float expectedBalance=21000;
		assertEquals(expectedBalance, bankingServices.withdrawAmount(1000, 155112, 5000, 1111),2);
	}
	
	
	@After
	public void tearDownMockData(){
		CGBankingUtility.CUSTOMER_ID_COUNTER=1000;
		CGBankingUtility.ACCOUNT_ID_COUNTER=155112;
		CGBankingUtility.TRANSACTION_ID_COUNTER=100;
		BankingDAOServicesImpl.customerList.clear();
	}
	@AfterClass
	public static void tearDownTestEnv(){
		bankingServices=null;
	}

}
