package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.CGBankingUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class BankingDAOServicesImpl implements BankingDAOServices,Serializable {
	private static HashMap<Integer, Customer> customerList=new HashMap<>();
	
	Random rand=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		customerList.put(CGBankingUtility.CUSTOMER_ID_COUNTER, customer);
		customer.setCustomerId(CGBankingUtility.CUSTOMER_ID_COUNTER);
		System.out.println(CGBankingUtility.CUSTOMER_ID_COUNTER);
		return customerList.get(CGBankingUtility.CUSTOMER_ID_COUNTER++).getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(CGBankingUtility.ACCOUNT_ID_COUNTER, account);
		account.setAccountNo(CGBankingUtility.ACCOUNT_ID_COUNTER++);
		account.setStatus("Active");
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(account.getAccountNo(), account);
		return true;
	}
	@Override
	public int generatePin(int customerId, Account account) { 
		long accountNo=account.getAccountNo();
		getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9999) + 1000);
		return getAccount(customerId, accountNo).getPinNumber(); 
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		getAccount(customerId, accountNo).getTransactionList().put(CGBankingUtility.TRANSACTION_ID_COUNTER, transaction);
		transaction.setTransactionId(CGBankingUtility.TRANSACTION_ID_COUNTER++);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		Customer c=customerList.remove(customerId);
		if(c==null)return false;
		return true;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		Account a=getCustomer(customerId).getAccountList().remove(accountNo);
		if(a==null)return false;
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		return getCustomer(customerId).getAccountList().get(accountNo);
	}
	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customerList.values());
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(getCustomer(customerId).getAccountList().values());
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
	return new ArrayList<>(getAccount(customerId, accountNo).getTransactionList().values());
	}
	public void doSerialization(File file) throws FileNotFoundException, IOException{
	try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))) {
		dest.writeObject(customerList);
		}
	}
	public void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException{
		
		if(file.length()!=0){	
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
			customerList=(HashMap<Integer, Customer>) src.readObject();
			ArrayList<Integer> keys=new ArrayList<>(customerList.keySet());
			CGBankingUtility.CUSTOMER_ID_COUNTER=Collections.max(keys)+1;
			for (Integer num : keys) { 
				if(!(customerList.get(num).getAccountList().isEmpty())){ 	
					ArrayList<Long> akeys=new ArrayList<>(customerList.get(num).getAccountList().keySet());
			        CGBankingUtility.ACCOUNT_ID_COUNTER=Collections.max(akeys)+1;
			        akeys.clear();
				    for(Long num1 : akeys){
				    	if(!(customerList.get(num).getAccountList().get(num1).getTransactionList().isEmpty())){
				    		ArrayList<Integer> tkeys=new ArrayList<>(customerList.get(num).getAccountList().get(num1).getTransactionList().keySet());
					     	CGBankingUtility.TRANSACTION_ID_COUNTER=Collections.max(tkeys)+1;
					     	tkeys.clear();
							 }
						 }
					 }
				 }
			 }
		
		}else return;
	}
}
