package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices services=(BankingServices)applicationContext.getBean("BankingServices");
		try {
			//services.acceptCustomerDetails("vishal", "sai", "sai@gmail.com", "VFDG58742", new ArrayList<Address>(Arrays.asList(new Address(400352, "pune", "mh"),new Address(500085, "hyd", "ts"))));
			//System.out.println(services.openAccount(1, "salary", 18500));
			//System.out.println(services.openAccount(2, "salary", 35500));
			//services.depositAmount(1, 2, 35000);
			//services.depositAmount(2, 6, 25000);
			//System.out.println(services.generateNewPin(1, 5));
			//System.out.println(services.generateNewPin(2, 6));
			//System.out.println(services.withdrawAmount(1, 5, 1, 3301));
			//System.out.println(services.fundTransfer(1, 5, 2, 6, 99, 3399));
			//System.out.println(services.getCustomerDetails(1));
			//services.removeCustomer(2);
			services.closeAccount(1, 3);
			//System.out.println(services.getAccountDetails(1, 3));
		} catch ( Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}