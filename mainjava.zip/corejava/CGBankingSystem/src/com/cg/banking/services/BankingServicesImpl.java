package com.cg.banking.services;

import java.io.File;
import java.util.Random;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesAccount;
import com.cg.banking.daoservices.BankingDAOServicesCustomer;
import com.cg.banking.daoservices.BankingDAOServicesTransaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component(value="BankingServices")
@Transactional
public class BankingServicesImpl implements BankingServices,Serializable  {
	@Autowired
	BankingDAOServicesCustomer daoservicesCustomer;
	@Autowired
	BankingDAOServicesAccount daoservicesAccount;
	@Autowired
	BankingDAOServicesTransaction daoservicesTransaction;
	
	public BankingServicesImpl() {}
	
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			List<Address> address) throws BankingServicesDownException {
		Customer customer=daoservicesCustomer.save(new Customer(firstName, lastName, emailId, panCard, address));
		return customer.getCustomerId();
	}
	

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(initBalance<0)
			throw new InvalidAmountException("Enter a valid amount");
		if(!(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")))
			 throw new InvalidAccountTypeException("Invalid account type");
		Customer customer=daoservicesCustomer.findOne(customerId);
		String status="Active";
		Account account=new Account(accountType, initBalance, status);
		account.setCustomer(customer);
		Account account1=daoservicesAccount.save(account);
		customer.getAccountList().put(account1.getAccountNo(), account1);
		return account.getAccountNo();
	}
	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException,InvalidAmountException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(!daoservicesAccount.findOne(accountNo).getStatus().equalsIgnoreCase("Active"))
			throw new AccountBlockedException("Account is blocked");
		if(amount<0) throw new InvalidAmountException("Invalid amount");
	    Account account=daoservicesAccount.findOne(accountNo);
		float finalamt=daoservicesAccount.findOne(accountNo).getAccountBalance()+amount;
		account.setAccountBalance(finalamt);
		daoservicesAccount.saveAndFlush(account);
		Transaction transaction=new Transaction(amount, "Deposit");
		transaction.setAccount(account);
		daoservicesTransaction.save(transaction);
		return daoservicesAccount.findOne(accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(daoservicesAccount.findOne(accountNo).getAccountBalance()<amount)
			throw new InsufficientAmountException("Insufficient Balance");
		while(daoservicesAccount.findOne(accountNo).getPinCounter()<=3&&daoservicesAccount.findOne(accountNo).getPinNumber()!=pinNumber){
			if(daoservicesAccount.findOne(accountNo).getPinNumber()!=pinNumber){
				daoservicesAccount.findOne(accountNo).setPinCounter(daoservicesAccount.findOne(accountNo).getPinCounter()+1);
				System.out.println(daoservicesAccount.findOne(accountNo).getPinCounter());
				throw new InvalidPinNumberException("Invalid Pin");
			}
		}
		if(daoservicesAccount.findOne(accountNo).getPinCounter()>3){  
			daoservicesAccount.findOne(accountNo).setStatus("Blocked");
			throw new AccountBlockedException("Account is blocked");
		}
		if(!daoservicesAccount.findOne(accountNo).getStatus().equals("Active"))
			throw new AccountBlockedException("Account is blocked");
		
		if(amount<0) throw new InvalidAmountException("Invalid amount");
		float finalamt=daoservicesAccount.findOne(accountNo).getAccountBalance()-amount;
		Account account=daoservicesAccount.findOne(accountNo);
		account.setPinCounter(0);
		account.setAccountBalance(finalamt);
		daoservicesAccount.saveAndFlush(account);
		Transaction transaction=new Transaction(amount, "Withdraw");
		transaction.setAccount(account);
		daoservicesTransaction.save(transaction);
		return daoservicesAccount.findOne(accountNo).getAccountBalance();
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(daoservicesCustomer.findOne(customerIdTo)==null&&daoservicesCustomer.findOne(customerIdFrom)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNoTo)==null&&daoservicesAccount.findOne(accountNoFrom)==null)
			throw new AccountNotFoundException("Account not found");
		if(!daoservicesAccount.findOne(accountNoTo).getStatus().equals("Active"))
			throw new AccountBlockedException("Account is blocked");
		withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		return daoservicesCustomer.findOne(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		return daoservicesAccount.findOne(accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		Random rand=new Random();
		Account account=daoservicesAccount.findOne(accountNo);
		int num=rand.nextInt(9999) + 1000;
		account.setPinNumber(num);
		daoservicesAccount.saveAndFlush(account);
		return num; 
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(daoservicesAccount.findOne(accountNo).getPinNumber()!=oldPinNumber)
			throw new InvalidPinNumberException("Invalid Pin");
		Account account=daoservicesAccount.findOne(accountNo);
		account.setPinNumber(newPinNumber);
		account.setStatus("Active");
		daoservicesAccount.saveAndFlush(account);
		return true;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return daoservicesCustomer.findAll();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		List<Account> accounts=(List<Account>) daoservicesCustomer.findOne(customerId).getAccountList().values();
		return accounts;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		List<Transaction> transactions=(List<Transaction>) daoservicesAccount.findOne(accountNo).getTransactionList().values();
		return transactions;
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(daoservicesAccount.findOne(accountNo).getStatus()!="Active")
			throw new AccountBlockedException("Account is blocked");
		return daoservicesAccount.findOne(accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservicesAccount.findOne(accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		Account account=daoservicesAccount.findOne(accountNo);
		daoservicesAccount.delete(account);
		 return true;
	}

	@Override
	public boolean removeCustomer(int customerId) throws BankingServicesDownException, CustomerNotFoundException {
		if(daoservicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		daoservicesCustomer.delete(customerId);
		return true;
	}
	@Override
	public String toString() {
		return "BankingServicesImpl [daoservices=" + daoservicesCustomer + "]";
	}




	
	

}
