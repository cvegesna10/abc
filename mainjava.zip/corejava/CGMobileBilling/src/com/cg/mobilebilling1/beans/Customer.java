package com.cg.mobilebilling1.beans;

public class Customer {
	private int customerId,mobileNo,adharNo,dateOfBirth;
	private String firstName,lastName,pancardNo,emailId;
	private Address address;
	private PostPaidAccount [] postpaidaccounts;
	public Customer() {}
	public Customer(int customerId, int mobileNo, int adharNo, int dateOfBirth, String firstName, String lastName,
			String pancardNo, String emailId, Address address, PostPaidAccount[] postpaidaccounts) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pancardNo = pancardNo;
		this.emailId = emailId;
		this.address = address;
		this.postpaidaccounts = postpaidaccounts;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public int getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public PostPaidAccount[] getPostpaidaccounts() {
		return postpaidaccounts;
	}
	public void setPostpaidaccounts(PostPaidAccount[] postpaidaccounts) {
		this.postpaidaccounts = postpaidaccounts;
	}
	
}
