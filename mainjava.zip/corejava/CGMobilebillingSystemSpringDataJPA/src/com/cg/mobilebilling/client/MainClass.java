package com.cg.mobilebilling.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
public class MainClass {
	public static void main(String[] args){
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServices services=(BillingServices)applicationContext.getBean("BillingServices");
		//System.out.println(services.acceptCustomerDetails("chandrahas", "vegesna", "varma@gmail.com", "10-01-1995", "hyd", "tg", 500085, "hyd", "tg", 500085));
		//services.createPlan();
		try {
			//services.openPostpaidMobileAccount(1, "9705030490", 1);
			//System.out.println(services.generateMonthlyMobileBill(1, "9705030490", "Feb", 100, 100, 100, 100, 100));
		//System.out.println(services.getCustomerDetails(1));
			//System.out.println(services.getPostPaidAccountDetails(1, "9705030490"));
		//System.out.println(services.getCustomerAllPostpaidAccountsDetails(1));
		//System.out.println(services.getMobileBillDetails(1, "9705030490", "Feb"));
		//services.changePlan(1, "9705030490", 2);
		//System.out.println(services.getCustomerPostPaidAccountPlanDetails(1, "9705030490"));
		services.closeCustomerPostPaidAccount(1, "9705030490");
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException | PostpaidAccountNotFoundException e) {
			e.printStackTrace();
		}
	}
}