package com.cg.mobilebilling.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServicesAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServicesBill;
import com.cg.mobilebilling.daoservices.BillingDAOServicesCustomer;
import com.cg.mobilebilling.daoservices.BillingDAOServicesPlan;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component(value="BillingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private BillingDAOServicesCustomer daoServicesCustomer;
	@Autowired
	private BillingDAOServicesAccount daoServicesAccount;
	@Autowired
	private BillingDAOServicesBill daoServicesBill;
	@Autowired
	private BillingDAOServicesPlan daoServicesPlan;

	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {

		return daoServicesPlan.findAll();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BillingServicesDownException {
		Customer customer=daoServicesCustomer.save(new Customer(firstName, lastName, emailID, dateOfBirth, new Address(billingAddressPinCode, billingAddressCity, billingAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID,String mobileNo, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Plan plan=daoServicesPlan.findOne(planID);
		PostpaidAccount account=new PostpaidAccount(mobileNo, plan);
		Customer customer=daoServicesCustomer.findOne(customerID);
		account.setCustomer(customer);
		daoServicesAccount.save(account);
		return 0;
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, String mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		float localSMSAmount,stdSMSAmount,localCallsAmount,stdCallsAmount,internetDataUsageAmount;
		PostpaidAccount account=daoServicesAccount.findOne(mobileNo);
		Plan plan=account.getPlan();
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth);
		if((plan.getFreeLocalSMS()-noOfLocalSMS)<0){
			localSMSAmount=(noOfLocalSMS-plan.getFreeLocalSMS())*plan.getLocalSMSRate();
		}else localSMSAmount=0;
		bill.setLocalSMSAmount(localSMSAmount);

		if((plan.getFreeStdSMS()-noOfStdSMS)<0){
			stdSMSAmount=(noOfStdSMS-plan.getFreeStdSMS())*plan.getStdSMSRate();
		}else stdSMSAmount=0;
		bill.setStdSMSAmount(stdSMSAmount);

		if((plan.getFreeLocalCalls()-noOfLocalCalls)<0){
			localCallsAmount=(noOfLocalCalls-plan.getFreeLocalCalls())*plan.getLocalCallRate();
		}else localCallsAmount=0;
		bill.setLocalCallAmount(localCallsAmount);

		if((plan.getFreeStdCalls()-noOfStdCalls)<0){
			stdCallsAmount=(noOfStdCalls-plan.getFreeStdCalls())*plan.getStdCallRate();
		}else stdCallsAmount=0;
		bill.setStdCallAmount(stdCallsAmount);

		if((plan.getFreeInternetDataUsageUnits()-internetDataUsageUnits)<0){
			internetDataUsageAmount=(internetDataUsageUnits-plan.getFreeInternetDataUsageUnits())*plan.getInternetDataUsageRate();
		}else internetDataUsageAmount=0;
		bill.setInternetDataUsageAmount(internetDataUsageAmount);
		float serviceTax=50,vat=50;
		bill.setServicesTax(serviceTax);
		bill.setVat(vat);
		bill.setTotalBillAmount(localSMSAmount+stdSMSAmount+localCallsAmount+stdCallsAmount+internetDataUsageAmount+serviceTax+vat);

		bill.setPostPaidAccount(account);
		daoServicesBill.save(bill);


		return bill.getBillID();
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return daoServicesCustomer.findOne(customerID);
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return daoServicesCustomer.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, String mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		return daoServicesAccount.findOne(mobileNo);
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Map<String, PostpaidAccount> accounts=daoServicesCustomer.findOne(customerID).getPostpaidAccounts();
		List<PostpaidAccount> account= new ArrayList<>(accounts.values()); 
		return account;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, String mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		
		Map<Integer, Bill> bills= daoServicesAccount.findOne(mobileNo).getBills();
		List<Bill> bill=new ArrayList<>(bills.values());
		for(Bill bil:bill){
			if(bil.getBillMonth().equals(billMonth))
				return bil;
		}
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, String mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Map<Integer, Bill> bills= daoServicesAccount.findOne(mobileNo).getBills();
		List<Bill> bill=new ArrayList<>(bills.values());
		return bill;
	}

	@Override
	public boolean changePlan(int customerID, String mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		if(planID==1||planID==2||planID==3){
			Customer customer=daoServicesCustomer.findOne(customerID);
			PostpaidAccount account=customer.getPostpaidAccounts().get(mobileNo);
			Plan plan=daoServicesPlan.findOne(planID);
			account.setPlan(plan);
			daoServicesAccount.saveAndFlush(account);
			return true;
		}
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, String mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		daoServicesAccount.delete(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		daoServicesCustomer.delete(customerID);
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, String mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=daoServicesCustomer.findOne(customerID);
		PostpaidAccount account=customer.getPostpaidAccounts().get(mobileNo);
		Plan plan=account.getPlan();
		return plan;
	}

	@Override
	public  void createPlan() {
		daoServicesPlan.save(new Plan(1000, 100, 100, 100, 100, 100, 1, 1, 1, 1, 10, "maharastra", "basicPlan"));
		daoServicesPlan.save(new Plan(2000, 100, 100, 100, 100,100, 2, 2, 2, 2, 20, "maharastra", "middlePlan"));
		daoServicesPlan.save(new Plan(3000, 100, 100, 100, 100, 100, 3, 3, 3, 3, 30, "maharastra", "highPlan"));
	} 



}