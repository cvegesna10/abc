package com.cg.payroll.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.exception.PayrollServicesDown;
import com.cg.payroll.services.PayrollServices;

@Controller
public class LoginController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/authUser")
	public String loginUser(@ModelAttribute("associate")Associate associate){
		try {
			List<Associate> associates=payrollServices.getAllAssociatesDetails();
			for(Associate assoc:associates){
			if(associate.getUserId().equals(assoc.getUserId())&&associate.getPassword().equals(assoc.getPassword())){	
				 ModelAndView mav = new ModelAndView();
				 mav.setViewName("Page");
				 mav.addObject("message", assoc);
				return "registrationSuccessPage";
				}
			}
			return "errorPage";
		} catch (PayrollServicesDown e) {
			 return "errorPage";
		}
	}
	@RequestMapping(value="/calcSalary",method = RequestMethod.POST, params={"userId"})
	public String calculateSalary(@RequestParam("userId") String userId){
		try {
			System.out.println(userId);
			List<Associate> associates=payrollServices.getAllAssociatesDetails();
			/*System.out.println(associate);
			for(Associate assoc:associates){
			if(associate.getUserId().equals(assoc.getUserId())){	
				payrollServices.calculateNetSalary(assoc.getAssociateId());
				associate=payrollServices.getAssociateDetails(assoc.getAssociateId());
				 ModelAndView mav = new ModelAndView();
				 mav.setViewName("salaryPage");
				 mav.addObject("message", associate);
				return "salaryPage";
				}*/
			//}
			return "errorPage";
		} catch (PayrollServicesDown e) {
			 return "errorPage";
		}
	}
}
