package com.cg.payroll.exception;

public class PayrollServicesDown extends Exception {

	public PayrollServicesDown() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDown(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDown(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDown(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDown(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
