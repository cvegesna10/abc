package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.exception.PayrollServicesDown;

public interface PayrollServices {

	int acceptAssociateDetails(Associate associate) throws PayrollServicesDown;
	
	public boolean deleteAssociate(int associateId)throws AssociateDetailsNotfoundException,PayrollServicesDown;
		
	float calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException,PayrollServicesDown;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotfoundException, PayrollServicesDown;

	List<Associate> getAllAssociatesDetails() throws PayrollServicesDown;

	boolean updateAssociateDetails(Associate associate)
			throws AssociateDetailsNotfoundException, PayrollServicesDown;

	

	}