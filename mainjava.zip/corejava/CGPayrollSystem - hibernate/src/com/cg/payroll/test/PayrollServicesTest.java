package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {
	private static PayrollServices payrollServices;
	
	@BeforeClass
	public static void setUpTestEnv(){
		payrollServices=new PayrollServicesImpl();
	}
	
	@Before
	public void setUpMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,55000, "chandrahas", "vegesna", "java", "trainee", "GSARSV252856", "varma@gmail.com", new Salary(25000, 1500, 1500),new BankDetails(5682341, "CITI", "CITI001"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,135000, "vishal", "sai", "java", "trainee", "MGEDXH2652", "vishal@gmail.com", new Salary(35000, 1200, 1200),new BankDetails(5682341, "AXIS", "AXIS985"));
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "daya", "samala", "java", "trainee", "QECBJJG5521", "daya@gmail.com", new Salary(30000, 1000, 1000),new BankDetails(5682341, "HDFC", "HDFC521"));
		PayrollDAOServicesImpl.associateList.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associateList.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associateList.put(associate3.getAssociateID(), associate3);
	}
	
	@Test
	public void testForAcceptAssociateDetailsForValidAssociateId(){
		int expectedAssociateId=114;
		int actualAssociateId=payrollServices.acceptAssociateDetails("meher", "prasad", "java", "meher@gmail.com", "trainee", "LRWEKS2159", 89000, 45200, 1000, 1000, 6857458, "AXIS", "AXIS875");
		assertEquals(expectedAssociateId, actualAssociateId);
	}
	@Test
	public void testForUpdateAssociateDetailsForValidAssociateId() throws AssociateDetailsNotfoundException{
		boolean expected=true;
		assertEquals(expected,payrollServices.updateAssociateDetails(112,"meher", "prasad", "java", "meher@gmail.com", "trainee", "LRWEKS2159", 89000, 45200, 1000, 1000, 6857458, "AXIS", "AXIS875"));
	}
	@Test(expected=AssociateDetailsNotfoundException.class)
	public void testForUpdateAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotfoundException{
		payrollServices.updateAssociateDetails(895,"meher", "prasad", "java", "meher@gmail.com", "trainee", "LRWEKS2159", 89000, 45200, 1000, 1000, 6857458, "AXIS", "AXIS875");
	}
	@Test
	public void testForGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotfoundException{
		assertEquals(new Associate(111, 55000, "chandrahas", "vegesna", "java", "trainee", "GSARSV252856", "varma@gmail.com", new Salary(25000, 1500, 1500),new BankDetails(5682341, "CITI", "CITI001")),payrollServices.getAssociateDetails(111));
	}
	@Test(expected=AssociateDetailsNotfoundException.class)
	public void testForGetAssociateDetailsForinValidAssociateId() throws AssociateDetailsNotfoundException{
		payrollServices.getAssociateDetails(672);
	}
	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotfoundException{
		assertEquals(50700, payrollServices.calculateNetSalary(113),0);
	}
	@Test(expected=AssociateDetailsNotfoundException.class)
	public void testCalculateNetSalaryForinValidAssociateId() throws AssociateDetailsNotfoundException{
		payrollServices.calculateNetSalary(007);
	}

	@Test
	public void testDeleteAssociateForValidAssociateId() throws AssociateDetailsNotfoundException{
		assertTrue(payrollServices.deleteAssociate(112));
	}
	@Test(expected=AssociateDetailsNotfoundException.class)
	public void testDeleteAssociateForInvalidAssociateId() throws AssociateDetailsNotfoundException{
		payrollServices.deleteAssociate(1);
	}
	@After
	public void tearDownMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		PayrollDAOServicesImpl.associateList.clear();
	}
	
	@AfterClass
	public static void tearDownTestEnv(){
		payrollServices=null;
	}
}
