package com.cg.payroll.utility;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.payroll.beans.Associate;

public class AssociateMapper implements RowMapper<Associate> {

	@Override
	public Associate mapRow(ResultSet resultSet, int i) throws SQLException {
		Associate associate=new Associate();
		associate.setAssociateID(resultSet.getInt(1));
		associate.setYearlyInvestmentUnder80C(resultSet.getInt("yearlyInvestmentUnder80C"));
		associate.setFirstName(resultSet.getString("firstName"));
		associate.setLastName(resultSet.getString("lastName"));
		associate.setDepartment(resultSet.getString("department"));
		associate.setDesignation(resultSet.getString("designation"));
		associate.setPancard(resultSet.getString("pancard"));
		associate.setEmailId(resultSet.getString("emailId"));
		
		return associate;
	}

}
