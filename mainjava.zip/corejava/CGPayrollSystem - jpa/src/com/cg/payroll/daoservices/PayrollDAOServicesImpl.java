package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;


@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	
	public PayrollDAOServicesImpl() {}
	
	@Override
	public int insertAssociate(Associate associate) {	
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate assoc= entityManager.find(Associate.class, associateId);
		System.out.println(assoc);
		entityManager.remove(assoc);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class, associateId);
	}

	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query q = entityManager.createQuery("from Associate a", Associate.class);
	    return q.getResultList(); 
	}
	
}