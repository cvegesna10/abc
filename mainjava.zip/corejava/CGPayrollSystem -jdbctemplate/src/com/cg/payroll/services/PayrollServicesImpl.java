package com.cg.payroll.services;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.exception.PayrollServicesDown;
@Component(value="PayrollServices")
public class PayrollServicesImpl implements PayrollServices,Serializable {
	private float annualTax;
	@Autowired
	private PayrollDAOServices daoservices;
	public PayrollServicesImpl() throws PayrollServicesDown{
	//	daoservices = new PayrollDAOServicesImpl();
	}
	
	@Override
	public int acceptAssociateDetails(String firstName,String lastName,String department,String emailId,String designation,String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode) throws PayrollServicesDown {
		
		try {
			return daoservices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollServicesDown("PayrollServices are down.please try again", e);
		}
	}
	 @Override
	public boolean updateAssociateDetails(int associateId,String firstName, String lastName, String department, String emailId,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode)throws AssociateDetailsNotfoundException, PayrollServicesDown {
		 try {
		 if(daoservices.getAssociate(associateId)==null)
				throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		 else{
			 	return daoservices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		 }
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDown("PayrollServices are down.please try again", e);
		}	
		 
	}
	 @Override
	 public boolean deleteAssociate(int associateId)throws AssociateDetailsNotfoundException, PayrollServicesDown{
		 try{
		 boolean a= daoservices.deleteAssociate(associateId);
		 if(a==false){
				throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		 }else return true;
		 } catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDown("PayrollServices are down.please try again", e);
		}
	 }
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException, PayrollServicesDown{
		try{
		if(this.getAssociateDetails(associateId)==null)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		
		Associate associate=getAssociateDetails(associateId);
		associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
		associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
		associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra());
		float annualSalary=12*associate.getSalary().getGrossSalary();
		if((associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()<150000)) {
			if(annualSalary>=1000000) {
				annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
			}
			else if(annualSalary>=500000&&annualSalary<1000000) {
				annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf())));
			}
			else if(annualSalary<500000 && annualSalary>=250000) {

				if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
					annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
				else 
					annualTax=0;
			}
			else if(annualSalary<250000)
				annualTax=0;
		}
		else {
			if(annualSalary>=1000000) 
				annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
			else if(annualSalary>=500000&&annualSalary<1000000)
				annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
			else if(annualSalary<500000 && annualSalary>=250000)

				if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
					annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
				else 
					annualTax=0;
			else
				annualTax=0;
		}
		associate.getSalary().setMonthlyTax(annualTax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		daoservices.updateAssociate(associate);
		return associate.getSalary().getNetSalary();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDown("PayrollServices are down.please try again", e);
		}
		}
	
	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotfoundException, PayrollServicesDown {
		try{
		Associate associate = daoservices.getAssociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		return associate;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDown("PayrollServices are down.please try again", e);
		}
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails()
	 */
	
	@Override
	public List<Associate> getAllAssociatesDetails() throws SQLException {
		return daoservices.getAssociates();		
	}
	/*public void serialization(File file) throws FileNotFoundException, IOException{
		daoservices.doSerialization(file);
	}
	public void deSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException{
		daoservices.doDeSerialization(file);;
	}*/
	
}
