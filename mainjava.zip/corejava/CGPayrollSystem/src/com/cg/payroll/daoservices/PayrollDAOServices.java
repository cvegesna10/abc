package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.payroll.beans.Associate;import com.cg.payroll.exception.PayrollServicesDown;

public interface PayrollDAOServices extends JpaRepository<Associate, Integer>{

	/*int insertAssociate(Associate associate);

	boolean updateAssociate(Associate associate);

	boolean deleteAssociate(int associateId);

	Associate getAssociate(int associateId);
	
	List<Associate> getAssociates();*/

}