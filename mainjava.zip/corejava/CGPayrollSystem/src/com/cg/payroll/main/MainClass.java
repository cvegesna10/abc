package com.cg.payroll.main;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServices;

import com.cg.payroll.exception.AssociateDetailsNotfoundException;
import com.cg.payroll.exception.PayrollServicesDown;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotfoundException, SQLException {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices services=(PayrollServices)applicationContext.getBean("PayrollServices");
		try {
		//System.out.println(services.acceptAssociateDetails("chandrahas", "vegesna", "java", "varma@gmail.com", "analyst", "JGXBJFG245", 125000, 35000, 1500, 1500, 321654, "CITI", "CITI002"));
		//System.out.println(services.acceptAssociateDetails("vishal", "sai", "java", "sai@gmail.com", "analyst", "EDSDAS552", 80000, 38000, 1500, 1500, 167415, "AXIS", "CITI002"));
		//	System.out.println(services.calculateNetSalary(1));
		//	System.out.println(services.calculateNetSalary(2));
		//System.out.println(services.getAssociateDetails(2));
		services.deleteAssociate(2);
		//System.out.println(services.getAllAssociatesDetails());
		} catch (PayrollServicesDown e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

