package com.cg.payroll.exception;

public class PayrollServicesDownException extends Exception {

	public PayrollServicesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PayrollServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
