package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
//import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotfoundException;
public class PayrollServicesImpl implements PayrollServices {
	private float annualTax;
	private PayrollDAOServices daoservices;
	public PayrollServicesImpl(){
	//	daoservices = new PayrollDAOServicesImpl();
	}
	
	public PayrollServicesImpl(PayrollDAOServices daoServices) {
		this.daoservices=daoServices;
	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, int, int, int, int, java.lang.String, java.lang.String)
	 */
	@Override
	public int acceptAssociateDetails(String firstName,String lastName,String department,String emailId,String designation,String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode){
		
		return daoservices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	 @Override
	public boolean updateAssociateDetails(int associateId,String firstName, String lastName, String department, String emailId,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode)throws AssociateDetailsNotfoundException {
		 if(daoservices.getAssociate(associateId)==null)
				throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		 else{
		 return daoservices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));	
		 }
	}
	 @Override
	 public boolean deleteAssociate(int associateId)throws AssociateDetailsNotfoundException{
		 boolean a= daoservices.deleteAssociate(associateId);
		 if(a==false)
				throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		return a; 
	 }
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException{
		if(this.getAssociateDetails(associateId)==null)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		
		Associate associate=getAssociateDetails(associateId);
		associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
		associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
		associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra());
		float annualSalary=12*associate.getSalary().getGrossSalary();
		if((associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()<150000)) {
			if(annualSalary>=1000000) {
				annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
			}
			else if(annualSalary>=500000&&annualSalary<1000000) {
				annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf())));
			}
			else if(annualSalary<500000 && annualSalary>=250000) {

				if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
					annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
				else 
					annualTax=0;
			}
			else if(annualSalary<250000)
				annualTax=0;
		}
		else {
			if(annualSalary>=1000000) 
				annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
			else if(annualSalary>=500000&&annualSalary<1000000)
				annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
			else if(annualSalary<500000 && annualSalary>=250000)

				if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
					annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
				else 
					annualTax=0;
			else
				annualTax=0;
		}
		associate.getSalary().setMonthlyTax(annualTax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		System.out.println( associate.getSalary().getNetSalary());
		return associate.getSalary().getNetSalary();
		}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotfoundException {
		Associate associate = daoservices.getAssociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotfoundException("Associate details of associateId"+associateId+"not found");
		return associate;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails()
	 */
	public List<Associate> getAssociatesDetails(){
		return daoservices.getAssociates();
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {
		// TODO Auto-generated method stub
		return null;
	}
}
