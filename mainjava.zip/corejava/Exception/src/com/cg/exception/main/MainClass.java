package com.cg.exception.main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		try {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter number");  
		int n1=scanner.nextInt();
		System.out.println("Enter number");  
		int n2=scanner.nextInt();
		System.out.println(n1/n2);
		System.out.println("Arithmetic Task completed here");
		}catch (InputMismatchException e) {
			e.printStackTrace();
			System.out.println("Enter only integer");
		} 
		catch (ArithmeticException e) {
			e.printStackTrace();
			System.out.println("Enter second number other than zero");
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Inside exception");
		}
		System.out.println("After try catch block");
	}

}
