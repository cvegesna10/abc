package com.cg.io.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Serialization implements Serializable{
	public static void doSerialization(File fromFile,File toFile) throws FileNotFoundException, IOException{
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(toFile))) {
				
	}
}
}
}