package com.cg.Library.Management.Beans;

public class User {

}
