package com.cg.project.services;

public class MainClass {

	public static void main(String[] args) {
		MathServices mathservices=new MathServicesImpl();
		System.out.println(mathservices.add(25, 30));
		System.out.println(mathservices.sub(25, 30));
		System.out.println(mathservices.div(25, 5));
		
	}

}
