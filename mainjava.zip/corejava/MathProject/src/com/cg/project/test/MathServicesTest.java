package com.cg.project.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.Exception.InValidNoRangeException;
import com.cg.project.services.MathServices;
import com.cg.project.services.MathServicesImpl;

//import junit.framework.Assert;


public class MathServicesTest {
	private static MathServices services;
	private int validNum1,validNum2,inValidNum1,inValidNum2,expectedAns;
	
	@BeforeClass
	public static void setUpTestEnv(){
		services=new MathServicesImpl();
	}
	
	@Before
	public void setUpMockData(){
		validNum1=10;
		validNum2=20;
		inValidNum1=-12;
		inValidNum2=-50;
	}
	
	@Test(expected=InValidNoRangeException.class)
	public void testAddForFirstInvalidNo()throws InValidNoRangeException{
		services.add(inValidNum1, validNum2);
	}
	@Test(expected=InValidNoRangeException.class)
	public void testAddForSecondInvalidNo()throws InValidNoRangeException{
		services.add(validNum1, inValidNum2);
	}
	@Test
	public void testAddForValidNo()throws InValidNoRangeException{
		Assert.assertEquals(30, services.add(validNum1, validNum2));
	}
	
	@Test(expected=InValidNoRangeException.class)
	public void testSubForFirstInvalidNo()throws InValidNoRangeException{
		services.sub(inValidNum1, validNum2);
	}
	@Test(expected=InValidNoRangeException.class)
	public void testSubForSecondInvalidNo()throws InValidNoRangeException{
		services.sub(validNum1, inValidNum2);
	}
	@Test
	public void testSubForValidNo()throws InValidNoRangeException{
		Assert.assertEquals(-10, services.sub(validNum1, validNum2));
	}
	
	
	
	@Test(expected=InValidNoRangeException.class)
	public void testDivForFirstInvalidNo()throws InValidNoRangeException{
		services.div(inValidNum1, validNum2);
	}
	@Test(expected=InValidNoRangeException.class)
	public void testDivForSecondInvalidNo()throws InValidNoRangeException{
		services.div(validNum1, inValidNum2);
	}
	@Test
	public void testDivForValidNo()throws InValidNoRangeException{
		Assert.assertEquals(0, services.div(validNum1, validNum2));
	}
	@After
	public void tearDownMockData(){
		validNum1=10;
		validNum2=20;
		inValidNum1=-12;
		inValidNum2=-50;
		expectedAns=0;
	}
	@AfterClass
	public static void tearDownTestEnv(){
		services=null;
	}
	
}
