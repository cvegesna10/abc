package com.cg.project.beans;

public final class CEmployee extends Employee{
	private int hrs,variablePay;
	public CEmployee() {
		super();
	}
	
	public CEmployee(int employeeId,String firstName, String lastName, int hrs) {
		super(employeeId,firstName,lastName);
		this.hrs = hrs;
	}

	public CEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateSalary(){
		this.variablePay=hrs*8000; 
	}
	public void contractSign(){
		System.out.println("Contract Signed");
	}
	@Override
	public String toString() {
		return "CEmployee [hrs=" + hrs + ", variablePay=" + this.variablePay + ", getEmployeeId()=" + getEmployeeId()
				+ ", getBasicSalary()=" + getBasicSalary() + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + "]";
	}
	
}
