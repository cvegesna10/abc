package com.cg.project.beans;

public class PEmployee extends Employee{
	private int hra,da,ta;
	public PEmployee() {
		super();
	}
	
	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	
	}

	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName, int hra, int da, int pa) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hra = hra;
		this.da = da;
		this.ta = ta;
	}

	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	public int getTa() {
		return ta;
	}
	public void setPa(int ta) {
		this.ta = ta;
	} 
	public void calculateSalary(){
		this.da=this.getBasicSalary()*10/100;
		this.hra=this.getBasicSalary()*5/100;
		this.ta=this.getBasicSalary()*8/100;
		this.setTotalSalary(this.getBasicSalary()+da+ta+hra);
	}

	@Override
	public String toString() {
		return "PEmployee [hra=" + hra + ", da=" + da + ", pa=" + ta + ", getEmployeeId()=" + getEmployeeId()
				+ ", getBasicSalary()=" + getBasicSalary() + ", getTotalSalary()=" + getTotalSalary()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName() + "]";
	}
	
}
