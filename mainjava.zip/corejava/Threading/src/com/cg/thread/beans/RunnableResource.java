package com.cg.thread.beans;

//public class MyThread extends Thread{
public class RunnableResource implements Runnable{

	
	public RunnableResource() {
		super();
	}
	
	@Override
	public void run(){
		Thread t=Thread.currentThread();
		if(t.getName().equals("thread-1")){
			for(int i=0;i<100;i++){
				if(i%2==0)
					System.out.println(i);
			}
		}
		else if(t.getName().equals("thread-2")){
			for(int j=0;j<100;j++){
				if(j%2!=0)
					System.out.println(j);
			}
		}
		}
	

}
