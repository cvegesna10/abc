package com.cg.thread.main;

import com.cg.thread.beans.Customer;
import com.cg.thread.beans.RunnableResource;

public class MainClass {
	
	public static void main(String[] args) {

		Thread th1=new Thread(new Customer(),"Rahul");
	    Thread th2=new Thread(new Customer(),"Ravi");
	    Thread th3=new Thread(new Customer(),"satish");
		th1.start();
		th2.start();
		th3.start();
	}

}
