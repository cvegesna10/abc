package com.cg.project.collections.beans;

import java.util.Comparator;

public class CustomerComparator implements Comparator<Customer> {

	@Override
	public int compare(Customer customer1, Customer customer2) {
		
		return customer1.getFirstName().compareTo(customer2.getFirstName());
	}
	
}
