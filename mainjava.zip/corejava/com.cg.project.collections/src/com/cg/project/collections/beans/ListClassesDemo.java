package com.cg.project.collections.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ListClassesDemo {
	public static void arrayListClassWork(){
		/*ArrayList<String>strList = new ArrayList<>();
		strList.add("chandrahas");
		strList.add("daya");
		strList.add("vishal");
		strList.add("vastava");
		
		Iterator<String> iterator=strList.iterator();
		while(iterator.hasNext()){
			String str=iterator.next();
		}*/
		ArrayList<Customer>cList = new ArrayList<>();
		cList.add(new Customer(155, "chandrahas", "vegesna"));
		cList.add(new Customer(125, "vishal", "sai"));
		cList.add(new Customer(205, "meher", "prasad"));
		cList.add(new Customer(1, "vastava", "m"));
		Collections.sort(cList);
		//System.out.println(cList);*/
		//Collections.sort(cList, new CustomerComparator());
		for(Customer cust : cList){
		System.out.println(cust);
		}
		}
}
