package com.cg.project.collections.beans;

public class MainClass {

	public static void main(String[] args) {
		ListClassesDemo.arrayListClassWork();
		
	}

}
