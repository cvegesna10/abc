package com.cg.project.collections.beans;

public class MyGenericClass {

}
