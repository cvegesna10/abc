package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	@FindBy(id="login_field")
	WebElement userName;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(className="btn")
	WebElement button;
	
	@FindBy(className="dropdown-signout")
	WebElement logoutbutton;
	
	public LoginPage() {}

	public LoginPage(WebElement userName, WebElement password, WebElement button) {
		super();
		this.userName = userName;
		this.password = password;
		this.button = button;
	}

	
	public LoginPage(WebElement userName, WebElement password, WebElement button, WebElement logoutbutton) {
		super();
		this.userName = userName;
		this.password = password;
		this.button = button;
		this.logoutbutton = logoutbutton;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName); 
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}

	public void clickSubmitButton() {
		button.submit();
	}

	public WebElement getLogoutbutton() {
		return logoutbutton;
	}

	public void clickLogoutbutton() {
		logoutbutton.submit();
	}
	
	
}
