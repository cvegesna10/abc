package com.cg.projectDemo;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.RegistrationPage;
public class RegistrationPageTest {
	static WebDriver driver;
	private RegistrationPage registrationPage;
	@BeforeClass
	public static void setUpDriverEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");	
		driver= new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUptestEnv() {
		driver.get("https://github.com/join");
		registrationPage=new RegistrationPage();
		PageFactory.initElements(driver, registrationPage);
	}
	@Test
	public void testForBlankUserNameAndPasswordAndEmail() {
		registrationPage.setUserName("");
		registrationPage.setPassword("");
		registrationPage.setEmail("");
		registrationPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);

	}

	@Test
	public void testForValidUserNameAndEmailAndPassword() {
		registrationPage.setUserName("abcd");
		registrationPage.setPassword("abcd");
		registrationPage.setEmail("abcd@gmail.com");
		registrationPage.clickSubmitButton();
	}

	@After
	public void tearDowntestEnv() {
		registrationPage=null;
	}

	@AfterClass
	public static void tearDownDriverEnv() {
		driver.close();
		driver=null;

	}
}
