package com.cg.seleniumDemo;

import java.io.ObjectInputStream.GetField;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        try {
			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.google.com");
			
			WebElement searchField=driver.findElement(By.id("lst-ib"));
			searchField.sendKeys("pluralsight");
			searchField.submit();
			
			WebElement imagesElement=driver.findElements(By.linkText("Images")).get(0);
			imagesElement.click();
			
			WebElement imageLink=driver.findElement(By.cssSelector("a[class=rg_l]"));
			imageLink.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
