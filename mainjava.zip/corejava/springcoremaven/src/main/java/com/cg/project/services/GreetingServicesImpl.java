package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices {

	@Override
	public void sayHello(String name) {
		System.out.println("Hello "+name+" !!!");
	}

	@Override
	public void sayGoodBye(String name) {
		System.out.println("Goodbye "+name);
	}



}
