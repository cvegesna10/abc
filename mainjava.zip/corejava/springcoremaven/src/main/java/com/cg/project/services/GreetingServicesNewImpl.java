package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesNewImpl implements GreetingServices{

	@Override
	public void sayHello(String name) {
		System.out.println("hi "+name);
		
	}

	@Override
	public void sayGoodBye(String name) {
		// TODO Auto-generated method stub
		
	}

}
