package com.cg.project.beans;

import java.util.List;

public class UserBean {
	private String firstName,lastName,userName,emailId,password,gender,graduation;
	private List<String> communication;
	public UserBean(String firstName, String lastName, String userName, String emailId, String password, String gender,
			String graduation, List<String> communication) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.emailId = emailId;
		this.password = password;
		this.gender = gender;
		this.graduation = graduation;
		this.communication = communication;
	}
	public UserBean(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public List<String> getCommunication() {
		return communication;
	}
	public void setCommunication(List<String> communication) {
		this.communication = communication;
	}
	
	
}
