package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config)");
	}

	public void destroy() {
		System.out.println("destroy()");
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter w=response.getWriter();
		w.println("<html>");
		w.println("<head>");
		w.println("</head>");
		w.println("<body>");
		w.println("<div align='center'>");
		w.println("<font color='olive'size='12'>");
		w.println("Hello");
		w.println("</font>");
		w.println("</div>");
		w.println("</body>");
		w.println("</html>");
	}

}
