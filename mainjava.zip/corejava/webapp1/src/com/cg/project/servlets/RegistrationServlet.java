package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public RegistrationServlet() {
        super();

    }

	
	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String emailId=request.getParameter("emailId");
		String password=request.getParameter("password");		
		String reEnterPassword=request.getParameter("reEnterPassword");
		String gender=request.getParameter("gender");
		String communication[]=request.getParameterValues("communication");
		String graduation=request.getParameter("graduation");
		String description[]=request.getParameterValues("description");
		//String resume=request.getParameter("Select Resume");
		RequestDispatcher dispatcher;
	//	UserBean userBean=new UserBean(firstName, lastName, userName, emailId, password, gender, graduation, communication);
		if(password.equals(reEnterPassword)){
		writer.println("<font color= 'blue' size=5>");
		writer.println("First Name: " +firstName );
		writer.println("<br>");
		writer.println("Last Name: " +lastName );
		writer.println("<br>");
		writer.println("User Name: " +userName );
		writer.println("<br>");
		writer.println("Password: " +password );
		writer.println("<br>");
		writer.println("Re-entered password: " +reEnterPassword );
		writer.println("<br>");
		writer.println("Gender: " +gender );
		writer.println("<br>");
		writer.println("Communication: " );
		for(String comm:communication){
		writer.print(comm+" " );
		}
		writer.println("<br>");
		writer.println("Graduation: "+graduation);
		writer.println("<br>");
		writer.println("DetailInformation: " );
		for(String desc:description){
			writer.print(desc+" " );
			}
	//	writer.println("<br>");
	//	writer.println("resume: " +resume );
		}else
			writer.println("<font color='red'size='12'>Passwords didn't match!!!</font>");
	}

}
